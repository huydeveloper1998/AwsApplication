package com.liberty.AwsApplication.s3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("s3")
public class S3Controller {

	@Autowired
	private S3Service s3Service;

	@GetMapping("list-buckets")
	public ResponseEntity<?> listBuckets() {
		return ResponseEntity.ok(s3Service.getBuckets());
	}

	// liberty-s3-v1-ap-southeast-1
	@PostMapping("create-bucket")
	public ResponseEntity<?> createBucket(@RequestParam String bucketName) {
		s3Service.createBucket(bucketName);
		return ResponseEntity.ok("Bucket name created successfully!!!!!");
	}

	@PostMapping("delete-bucket")
	public ResponseEntity<?> deleteBucket(@RequestParam String bucketName) {
		s3Service.deleteBucket(bucketName);
		return ResponseEntity.ok("Bucket name deleted successfully!!!!!");
	}

	@GetMapping("list-objects")
	public ResponseEntity<?> listObjects(@RequestParam String bucketName) {
		return ResponseEntity.ok(s3Service.getObjects(bucketName));
	}

	@PostMapping("create-object")
	public ResponseEntity<?> createObject(@RequestParam String bucketName, @RequestPart MultipartFile file) {
		s3Service.createObject(bucketName, file);
		return ResponseEntity.ok("Object created successfully!!!!!");
	}

	@PostMapping("delete-object")
	public ResponseEntity<?> deleteObject(@RequestParam String bucketName, @RequestParam String fileName) {
		s3Service.deleteObject(bucketName, fileName);
		return ResponseEntity.ok("Object deleted successfully!!!!!");
	}

	@PostMapping("download-object")
	public ResponseEntity<?> downloadObject(@RequestParam String bucketName, @RequestParam String fileName) {
		Resource resource = s3Service.downloadObject(bucketName, fileName);

		return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"").body(resource);
	}
}
