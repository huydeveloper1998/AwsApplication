package com.liberty.AwsApplication.s3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.ListBucketsResponse;
import software.amazon.awssdk.services.s3.model.ListObjectsResponse;
import software.amazon.awssdk.services.s3.model.S3Exception;

@Service
public class S3Service {

	private S3Client s3Client;

	public S3Service(@Value("${liberty.regionName}") String regionName, AwsCredentials credentials) {
		this.s3Client = S3Client.builder().region(Region.of(regionName))
				.credentialsProvider(StaticCredentialsProvider.create(credentials)).build();
	}

	public void createBucket(String bucketName) {
		this.s3Client.createBucket(req -> req.bucket(bucketName));
	}

	public List<Map<String, Object>> getBuckets() {
		List<Map<String, Object>> listBuckets = new ArrayList<Map<String, Object>>();
		String nextToken = null;

		do {
			String continuationToken = nextToken;
			ListBucketsResponse listBucketsResponse = s3Client
					.listBuckets(request -> request.continuationToken(continuationToken));

			listBucketsResponse.buckets().forEach(item -> {
				Map<String, Object> bucket = new HashMap<String, Object>();
				bucket.put("name", item.name());
				bucket.put("region", item.bucketRegion());
				bucket.put("createtionDate", item.creationDate());

				listBuckets.add(bucket);
			});

			nextToken = listBucketsResponse.continuationToken();
		} while (nextToken != null);
		return listBuckets;
	}

	public void deleteBucket(String bucketName) {
		try {
			for (Map<String, Object> object : getObjects(bucketName)) {
				deleteObject(bucketName, (String) object.get("key"));
			}

			s3Client.deleteBucket(request -> request.bucket(bucketName));
		} catch (S3Exception e) {
			e.printStackTrace();
		}
	}

	public void createObject(String bucketName, MultipartFile multipartFile) {
		String objectKey = multipartFile.getOriginalFilename();
		try {
			this.s3Client.putObject(request -> request.bucket(bucketName).key(objectKey).ifNoneMatch("*"),
					RequestBody.fromBytes(multipartFile.getBytes()));
		} catch (AwsServiceException | SdkClientException | IOException e) {
			e.printStackTrace();
		}
	}

	public List<Map<String, Object>> getObjects(String bucketName) {
		List<Map<String, Object>> listObjects = new ArrayList<Map<String, Object>>();

		ListObjectsResponse listObjectsResponse = s3Client.listObjects(req -> req.bucket(bucketName));
		listObjectsResponse.contents().forEach(item -> {
			Map<String, Object> bucket = new HashMap<String, Object>();
			bucket.put("key", item.key());
			bucket.put("size", item.size());
			bucket.put("lastModified", item.lastModified());
			bucket.put("owner", item.owner());

			listObjects.add(bucket);
		});

		return listObjects;
	}

	public void deleteObject(String bucketName, String objectKey) {
		this.s3Client.deleteObject(request -> request.bucket(bucketName).key(objectKey));
	}

	public Resource downloadObject(String bucketName, String objetKey) {

		ResponseBytes<GetObjectResponse> responseBytes = s3Client
				.getObject(request -> request.bucket(bucketName).key(objetKey), ResponseTransformer.toBytes());

		return new ByteArrayResource(responseBytes.asByteArray());
	}
}
